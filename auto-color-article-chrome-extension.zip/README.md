Extension for google chrome which automatically add colors to an article paragraphs.
